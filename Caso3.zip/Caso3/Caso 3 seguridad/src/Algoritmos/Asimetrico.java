package Algoritmos;


import java.security.InvalidKeyException;

import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;


import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


public class Asimetrico
{
	//Algoritmo a utilizar
	private final static String ALGORITMO="RSA";
	
	/**
	 * Cifra el mensaje dado por parametro 
	 * @param mensaje mensaje a cifrar
	 * @param llave con la que se cifrar�
	 * @return arreglo de bytes resultado del cifrado
	 */
	public byte[] cifrar(String mensaje, PublicKey llave) 
	{
		try 
		{
		KeyPairGenerator generator =
		KeyPairGenerator.getInstance(ALGORITMO);
		generator.initialize(1024);
		Cipher cipher = Cipher.getInstance(ALGORITMO);
		String pwd = mensaje;
		byte [] clearText = pwd.getBytes();

		cipher.init(Cipher.ENCRYPT_MODE, llave);

		byte [] cipheredText = cipher.doFinal(clearText);
		
		return cipheredText;
		}
		catch (Exception e) 
		{
		System.out.println("Excepcion: " + e.getMessage());
		return null;
		}
	}
	
	/**
	 * Descifra la cadena de bytes dada con la llave del parametro
	 * @param cipheredText cadena de bytes a descifrar
	 * @param llave con la cual se descifrara el mensaje
	 * @return mensaje descifrado
	 * @throws Exception, si el proceso falla
	 */
	public String descifrar(byte[] cipheredText, PublicKey llave) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		
		Cipher cipher = Cipher.getInstance(ALGORITMO);
		cipher.init(Cipher.DECRYPT_MODE, llave);
		byte [] clearText = cipher.doFinal(cipheredText);
		String s3 = new String(clearText);
		return s3;
		
	}

}
