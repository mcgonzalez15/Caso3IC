package Algoritmos;

import java.security.MessageDigest;

public class CifradoHash 
{
	
	private byte[] getKeyedDigest(byte[] buffer) 
	{
		try 
		{
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		 md5.update(buffer);
		 return md5.digest();
		 } catch (Exception e) {
		 return null;
		 }
	}
	
	/**
	 * Calcula la funci�n de hash para el mensaje dado
	 * @param mensaje sobre el cual se calcular� la funci�n de hash
	 * @return arreglo de bytes resultado de la funci�n hash.
	 */
	public byte[] calcular(String mensaje) 
	{
		try
		{
			
		String dato = mensaje;
		byte[] text = dato.getBytes();
		byte [] digest = getKeyedDigest(text);
		return digest;
		}
		catch (Exception e) 
		{
		System.out.println("Excepcion: " + e.getMessage());
		return null;
		}
	}

}
