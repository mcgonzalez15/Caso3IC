package Algoritmos;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;

import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class Simetrico {

	
	private final static String PADDING="AES/ECB/PKCS5Padding";


	/**
	 * Cifra el mensaje dado por parametro 
	 * @param mensaje mensaje a cifrar
	 * @param llave con la que se cifrar�
	 * @return arreglo de bytes resultado del cifrado
	 */
	public byte[] cifrar(String mensaje, SecretKey llave)
	{
		byte [] cipheredText;
		try {
			Cipher cipher = Cipher.getInstance(PADDING);
			String pwd = mensaje;
			byte [] clearText = pwd.getBytes();
			cipher.init(Cipher.ENCRYPT_MODE, llave);
			cipheredText = cipher.doFinal(clearText);
			return cipheredText;
		}
		catch (Exception e) {
			System.out.println("Excepcion: " + e.getMessage());
			return null;
		}
	}

	/**
	 * Descifra la cadena de bytes dada con la llave del parametro
	 * @param cipheredText cadena de bytes a descifrar
	 * @param llave con la cual se descifrara el mensaje
	 * @return mensaje descifrado
	 * @throws Exception, si el proceso falla
	 */
	public String descifrar(byte [] cipheredText, SecretKey llave) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		Cipher cipher = Cipher.getInstance(PADDING);
		cipher.init(Cipher.DECRYPT_MODE, llave);
		byte [] clearText = cipher.doFinal(cipheredText);
		String s3 = new String(clearText);
		return s3;

	}

}
