package Cliente;

import uniandes.gload.core.LoadGenerator;
import uniandes.gload.core.Task;

public class Generator
{
	private LoadGenerator generator;
	
	public Generator()
	{
		Task tarea= crearTarea();
		int numeroTareas=80;
		int espacioEntreTareas=100;
		generator= new LoadGenerator("Client - Server Load Test", numeroTareas,tarea, espacioEntreTareas);
		generator.generate();
	}

	private Task crearTarea() 
	{
		
		return new ClientServerClass();
	}
	
	public static void main(String[] args) 
	{
		Generator gen= new Generator();
	

	}
}