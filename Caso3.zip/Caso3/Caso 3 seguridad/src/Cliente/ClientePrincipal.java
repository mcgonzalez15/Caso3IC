package Cliente;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigInteger;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Provider;
import java.security.Security;

import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import Algoritmos.Asimetrico;
import Algoritmos.CifradoHash;
import Algoritmos.Simetrico;

/**
 * @author Christian Chavarro, Juan Sanmiguel
 */



public class ClientePrincipal 
{
	// constantes Socket
	//COLOQUE LA IP DEL SERVIDOR
	public final static String HOST ="192.168.1.111";
	public final static int puerto =5000;

	// Constantes de encriptación
	public final static String  AES = "AES";
	public final static String BLOWFISH = "BLOWFISH";
	public final static String RSA = "RSA";
	public final static String HMACMD5 = "HMACMD5";
	public final static String HMACSHA1 = "HMACSHA1";
	public final static String HMACSHA256 = "HMACSHA256";

	//Constantes de comunicación
	public final static String CERTIFICADO = "CERTCLNT";
	public final static String ALGORITMOS = "ALGORITMOS:"+AES+":"+RSA+":"+HMACMD5;
	public final static String OK = "ESTADO:OK";
	public final static String ERROR = "ESTADO:ERROR";
	public final static String ACT1 = "ACT1:";
	public final static String ACT2 = "ACT2:";


	//Atributos del socket
	boolean ejecutar = true;
	Socket socket = null; 
	PrintWriter escritor = null; 
	BufferedReader lector = null;
	String coordenadasPrueba = "4124.2028,210.4418";


	public long obtencionL=0;
	public long tiempo=0;

	//llave
	private KeyPair keyPair;
	private X509Certificate certificadoCliente;
	private SecretKey desKey;
	//Tiempo de inicio del programa
	public static long 	tiempoini;
	private final static String PADDING="AES/ECB/PKCS5Padding";

	//Clases que se usarán para los cifrados.
	private static Simetrico simetrico = new Simetrico();
	private static Asimetrico asimetrico = new Asimetrico();
	private static CifradoHash hash = new CifradoHash();


	//Construtor del cliente, ejecuta el protocolo
	public ClientePrincipal() throws Exception
	{
		//Se intenta crear el socket, lector y escritor.
		long medicion1a=0;
		long medicion1b=0;
		long medicion2a = 0;
		long medicion2b=0;
		try 
		{
			socket = new Socket(HOST,  puerto);
			escritor = new PrintWriter( socket.getOutputStream(), true);
			lector = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (Exception e) {
			System.err.println("Exception: " + e.getMessage()); System.exit(1);
		}

		try {
			BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));

			//Identificadores de mensajes, de quien proviene
			String fromServer = "";
			String fromUser="";
			//Identificador del paso del protocolo en el que se encuentra.
			int pasoActual= 0;
			boolean usarComando = true;
			int cantidades= 1;

			//Ciclo que realiza los avances en el protocolo, cuando no hay tareas por realizar, termina.
			while (ejecutar)
			{
				//Decide cuál comando utilizar
				if(usarComando)
				{
					//En este paso debe enviar HOLA el cliente
					if(pasoActual==0)
					{

						fromUser ="HOLA";
						tiempoini=System.currentTimeMillis(); 
						pasoActual++;
					}

					//Este paso es el de enviar los algoritmos que se van a usar
					else if(pasoActual==1)
					{
						fromUser= ALGORITMOS; 
						pasoActual++;
					}

					//Se envia el inicio del certificado
					else if(pasoActual==2)
					{
						fromUser= CERTIFICADO; 
						pasoActual++;
					}
					else if(pasoActual ==3)
					{
						//Genera el certificado para enviarlo posteriormente.
						KeyPairGenerator keyGen = KeyPairGenerator.getInstance(RSA);
						this.keyPair = keyGen.generateKeyPair();
						Security.addProvider((Provider)new BouncyCastleProvider());
						keyGen.initialize(1024);
						X509Certificate cert = generateV3Certificate(this.keyPair);
						StringWriter wr = new StringWriter();
						JcaPEMWriter pemWriter = new JcaPEMWriter((Writer)wr);
						pemWriter.writeObject((Object)cert);
						pemWriter.flush();
						pemWriter.close();
						String certStr = wr.toString();
						fromUser = certStr;
						pasoActual++;
					}
					//Paso de verificación contra el servidor.
					else if (pasoActual ==4)
					{
						pasoActual++;
					}
					else if(pasoActual == 5)
					{
						//Se recibe la llave por parte del servidor.
						medicion1b=System.currentTimeMillis();
						obtencionL=medicion1b-medicion1a;
						String[] partes = fromServer.split(":");
						if(partes.length > 1)
						{
							byte[] decodedKey =	DatatypeConverter.parseHexBinary(partes[1]);
							// rebuild key using SecretKeySpec
							String param = "RSA";
							param = param + ((param.equals("DES")) || (param.equals("AES")) ? "/ECB/PKCS5Padding" : "");
							Cipher localCipher = Cipher.getInstance(param);
							localCipher.init(2, keyPair.getPrivate());
							byte [] ls = localCipher.doFinal(decodedKey);
							desKey = new SecretKeySpec(ls, 0, 16, "AES"); 
							pasoActual++;
						}

					}
					//Pasos de avance en el contador, el cifrado se realiza en la siguiente verificación.
					else if(pasoActual == 6)
					{
						pasoActual++;

					}
					else if(pasoActual == 7)
					{

						pasoActual++;
					}

				}

				//VErifica si el mensaje del usuario tiene contenido
				if (fromUser != null && !fromUser.equals("-1")) 
				{

					//Imprimen los mensajes que el usuario envia al servidor.
					if(pasoActual == 1)
					{
						System.out.println("Cliente:("+pasoActual+")" + fromUser); 
						escritor.println(fromUser);
					}
					else if(pasoActual ==2)
					{
						System.out.println("Cliente:("+pasoActual+")" + fromUser); 
						escritor.println(fromUser);
					}
					else if(pasoActual ==3)
					{
						System.out.println("Cliente:("+pasoActual+")" + fromUser); 

						escritor.println(fromUser);
						continue;
					}
					else if(pasoActual ==4)
					{
						System.out.println("Cliente:("+pasoActual+")" + fromUser); 
						escritor.println(fromUser);
						medicion1a=System.currentTimeMillis();

					}

					//Cifra las coordenadas con la llave simetrica.
					//Envia al servidor las coordenadas cifradas, las envia bajo el protocolo
					else if(pasoActual==6)
					{
						medicion2a=System.currentTimeMillis();
						byte[] mensaje = simetrico.cifrar(coordenadasPrueba, desKey);
						String msg= ACT1 + DatatypeConverter.printHexBinary(mensaje);

						escritor.println(msg);
						System.out.println("Cliente:("+pasoActual+")" + msg);
						continue;
					}

					//Cifra el resultado de la función de hash de las coordenadas.
					//Este cifrado se realiza con la llave pública del servidor
					//Envia al servidor el mensaje de hash cifrado.
					else if(pasoActual ==7)
					{
						Mac mac = Mac.getInstance("hmacMD5");
						mac.init(desKey);

						byte[] utf8 = coordenadasPrueba.getBytes("utf8");
						byte[] digest = mac.doFinal(utf8);
						Cipher encrypt = Cipher.getInstance("RSA");
						encrypt.init(Cipher.ENCRYPT_MODE, certificadoCliente.getPublicKey());														
						byte[] codigoEncriptado = encrypt.doFinal(digest);
						String codigoVerificacion = DatatypeConverter.printHexBinary(codigoEncriptado);
						String	mensaje = ACT2 +codigoVerificacion;
						escritor.println(mensaje);
						System.out.println("Cliente:("+pasoActual+")" + mensaje);

						pasoActual++;
					}

					//Notifica el fin, cierra el ciclo de ejecución.
					else if(pasoActual ==8)
					{
						medicion2b=System.currentTimeMillis();
						tiempo=medicion2b-medicion2a;
						escribirLog();
						System.out.println("Fin"); 
						escritor.println(fromUser);				
						ejecutar =false;
					}


				}
				//Verifica las respuestas del servidor
				if(ejecutar==true) {
					if ((fromServer = lector.readLine()) != null)
					{

						System.out.println("Servidor: " + fromServer); 
						//Si la respuesta es de error, finaliza la ejecución
						if(fromServer.equals("ERROR"))
						{
							ejecutar = false;
						}

						if(pasoActual == 1 && fromServer.equals("Error en el formato. Cerrando conexion"))
						{
							System.exit(0);
						}

						//Verifica el certificado que el servidor envia.
						if(pasoActual == 4)
						{ 
							while(cantidades<=2 &&(fromServer = lector.readLine()) != null)
							{
								System.out.println("Servidor: " + fromServer); 
								cantidades++;
								if(cantidades ==2){
									verificarCertificado();
									pasoActual++;
								}

								break;
							}
						}
					}}





			}

			//Cierra el lector y escritor.
			escritor.close();
			lector.close();
			// cierre el socket y la entrada estándar
			socket.close();

		} catch (UnknownHostException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public  void escribirLog() throws IOException
	{

		File f1 = new File("./docs/pruebas80/8hilos/prueba10/llave.txt");
		File f2 = new File("./docs/pruebas80/8hilos/prueba10/respuestaServer.txt");


		FileWriter fw1 = new FileWriter(f1.getAbsoluteFile(),true);
		BufferedWriter bw1 = new BufferedWriter(fw1);
		bw1.append(obtencionL+"");
		bw1.append("\r\n");
		bw1.close();

		FileWriter fw2 = new FileWriter(f2.getAbsoluteFile(),true);
		BufferedWriter bw2 = new BufferedWriter(fw2);
		bw2.append(tiempo+"");
		bw2.append("\r\n");
		bw2.close();
	}



	//Generador de X509Certificate que necesita una llave por parámetro
	public static X509Certificate generateV3Certificate(KeyPair pair) throws Exception {
		X500NameBuilder nameBuilder = new X500NameBuilder(BCStyle.INSTANCE);
		nameBuilder.addRDN(BCStyle.OU, "OU");
		nameBuilder.addRDN(BCStyle.O, "O");
		nameBuilder.addRDN(BCStyle.CN, "CN");
		String stringDate1 = "2016-10-01";
		String stringDate2 = "2020-12-20";
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date notBefore = null;
		Date notAfter = null;
		try {
			notBefore = format.parse(stringDate1);
			notAfter = format.parse(stringDate2);
		}
		catch (ParseException e) {
			e.printStackTrace();
		}
		BigInteger serialNumber = new BigInteger(128, new Random());
		JcaX509v3CertificateBuilder certificateBuilder = new JcaX509v3CertificateBuilder(nameBuilder.build(), serialNumber, notBefore, notAfter, nameBuilder.build(), pair.getPublic());
		X509Certificate certificate = null;
		try {
			ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSAEncryption").build(pair.getPrivate());
			certificate = new JcaX509CertificateConverter().getCertificate(certificateBuilder.build(contentSigner));
		}
		catch (OperatorCreationException e) {
			e.printStackTrace();
		}
		catch (CertificateException e) {
			e.printStackTrace();
		}
		return certificate;
	}




	/**
	 *  Verifica el certificado recibido del servidor.
	 * @throws IOException si el flujo de entrada no está disponible
	 * @throws CertificateException si no logra obtenerse la instancia de la fabrica de certificados
	 */
	public void verificarCertificado() throws IOException, CertificateException
	{
		InputStream is = socket.getInputStream();
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		byte[] certificadoClienteBytes = new byte['ᎈ'];

		is.read(certificadoClienteBytes);
		InputStream inputStream = new ByteArrayInputStream(certificadoClienteBytes);

		try {
			certificadoCliente = ((X509Certificate)certFactory.generateCertificate(inputStream));
		} catch (CertificateException ce) {
			System.out.println("Cliente:"+ERROR);
			escritor.println( ERROR);
		}
		escritor.println(OK);
	}




	/**
	 * Describra la cadena de bytes que llega por parametro
	 * @param cipheredText cadena de bytes a descifrar
	 */
	public void descifrar(byte [] cipheredText) 
	{ try 
	{
		Cipher cipher = Cipher.getInstance(PADDING); cipher.init(Cipher.DECRYPT_MODE, desKey);
		byte [] clearText = cipher.doFinal(cipheredText); String s3 = new String(clearText); System.out.println("clave original: " + s3);
	}
	catch (Exception e) {
		System.out.println("Excepcion: " + e.getMessage()); }
	}




	/**
	 * Convierte  de hexagesimal a String
	 * @param array Arreglo de bytes a convertir
	 * @return string convertido
	 */
	public static String toHexString(byte[] array) {
		return DatatypeConverter.printHexBinary(array);
	}



	/**
	 * Convierte  de string a arreglo de bytes
	 * @param String a convertir
	 * @return Arreglo de bytes convertido
	 */
	public static byte[] toByteArray(String s) {
		return DatatypeConverter.parseHexBinary(s);
	}




	/**
	 * Cifra una cadena
	 * @return cadena de bytes cifrada
	 */
	public byte[] cifrar() 
	{ 
		byte [] cipheredText;
		try {
			KeyGenerator keygen = KeyGenerator.getInstance(AES); desKey = keygen.generateKey();
			Cipher cipher = Cipher.getInstance(PADDING);
			BufferedReader stdIn = new BufferedReader(
					new InputStreamReader(System.in));
			String pwd = stdIn.readLine();
			byte [] clearText = pwd.getBytes();
			String s1 = new String (clearText); System.out.println("clave original: " + s1);
			cipher.init(Cipher.ENCRYPT_MODE, desKey); long startTime = System.nanoTime(); cipheredText = cipher.doFinal(clearText); long endTime = System.nanoTime();
			String s2 = new String (cipheredText); System.out.println("clave cifrada: " + s2); System.out.println("Tiempo: " + (endTime - startTime)); return cipheredText;
		}
		catch (Exception e) {
			System.out.println("Excepcion: " + e.getMessage());
			return null; }
	}

	//
	//	/**
	//	 * Método main.
	//	 * @param args
	//	 * @throws IOException
	//	 */
	//	public static void main(String[] args) throws IOException { 
	//		try {
	//
	//			ClientePrincipal cliente = new ClientePrincipal();
	//			Long tiempofin=System.currentTimeMillis();
	//			System.out.println("El tiempo de ejecución fue: "+(tiempoini-tiempofin)*-1+"ms.");
	//			System.exit(1);
	//		} catch (Exception e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//		}
	//	}


}
