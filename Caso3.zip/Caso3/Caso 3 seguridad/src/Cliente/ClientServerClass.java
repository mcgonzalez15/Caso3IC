package Cliente;

import uniandes.gload.core.Task;

public class ClientServerClass extends Task
{
	
	@Override
	public void fail()
	{
		// TODO Auto-generated method stub
		System.out.println(Task.MENSAJE_FAIL);
	}

	@Override
	public void success() 
	{
		// TODO Auto-generated method stub
	

	}

	@Override
	public void execute() 
	{
		
		try {
			ClientePrincipal cliente= new ClientePrincipal();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			fail();
		
		}
		
	}

}